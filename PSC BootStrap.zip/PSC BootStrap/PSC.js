function switchLightOn(checkColor)             //This function takes a light ID number.  It then switches the given light on or off.
{
    var lightCommandGreen = {"on" : true, "hue" : 25500};       //JSON to send to the lights 25500=greeen , 
    var lightCommandRed = {"on" : true, "hue" : 65535};
    var lightCommandBlue = {"on" : true, "hue" : 46920};
    var lightCommandNEC = {"on" : true, "hue" : 12299};
    var lightCommandSpace = {"on" : true, "hue" : 33333};
    var lightCommandOff={"on":false};
    var lightURI = "http://192.168.0.50/api/stlaB2I6VZ8O80Qepc-1xfmLrHgyTFvB9IGupaQz/lights/1/state/";
    var lightURI2 = "http://192.168.0.50/api/stlaB2I6VZ8O80Qepc-1xfmLrHgyTFvB9IGupaQz/lights/2/state/";
    var lightURI3= "http://192.168.0.50/api/stlaB2I6VZ8O80Qepc-1xfmLrHgyTFvB9IGupaQz/lights/3/state/";
    var lightURI4 = "http://192.168.0.50/api/stlaB2I6VZ8O80Qepc-1xfmLrHgyTFvB9IGupaQz/lights/4/state/";
    var lightURI5 = "http://192.168.0.50/api/stlaB2I6VZ8O80Qepc-1xfmLrHgyTFvB9IGupaQz/lights/5/state/";
    var lightURI6 = "http://192.168.0.50/api/stlaB2I6VZ8O80Qepc-1xfmLrHgyTFvB9IGupaQz/lights/6/state/";
    console.log(lightURI);      //Check in the console that lightURI value is correct

    
    if(checkColor==1)
        {
            $.ajax({
                url: lightURI,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandRed)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI2,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandRed)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI3,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandRed)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI4,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandRed)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI5,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandRed)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI6,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandRed)  //translates contents of lightCommand variable into jSON code
            })
        }
    if(checkColor==2)
        {
            $.ajax({
                url: lightURI,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandBlue)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI2,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI3,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI4,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI5,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI6,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            })
        }
    
    if(checkColor==3)
        {
            $.ajax({
                url: lightURI,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandGreen)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI2,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI3,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI4,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI5,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI6,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            })
        }
    if(checkColor==4)
        {
            $.ajax({
                url: lightURI,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandSpace)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI2,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI3,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI4,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI5,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI6,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            })
        }
    if(checkColor==5)
        {
            $.ajax({
                url: lightURI,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandNEC)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI2,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI3,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI4,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI5,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            }),
            $.ajax({
                url: lightURI6,                      //uses variable lightURI
                type: "PUT",
                data: JSON.stringify(lightCommandOff)  //translates contents of lightCommand variable into jSON code
            })
        }
}

function showPass()
    {
        var symbols , pass , symCheck , html , newHtml , space , isalp , isnum , issym , check;
        isalp=0;
        space=0;
        isnum=0;
        issym=0;
        symCheck=0;
        pass = document.querySelector("#inpFeild").value;
        symbols=["!","@","#","$","%","^","&","*","(",")","_","-","=","+"];      //Symbols to check
        html='%text%';
        
        if(pass.length>8)
        {
             //Checking the values
            for(var i=0;i<pass.length;i++)
                {
                    console.log(pass[i]);
                    if(pass[i]==" ")
                        {
                            console.log("space");
                            
                            space=1;
                        }
                    if(!isNaN(pass[i]))
                        {
                            console.log("Number");
                            isnum=1;
                        }
                    if(isNaN(pass[i]))
                        {
                            symCheck=0;
                            symbols.forEach(function(e){
                                if(pass[i]==e)
                                {
                                    symCheck=1;  
                                }
                            });
                            if(symCheck==1)
                                {
                                    console.log("Symbol");
                                    issym=1;
                                }
                            else
                                {
                                    isalp=1;
                                    console.log("Alphaet");
                                }
                            
                        }
                }

            check=issym+isalp+isnum;


            //SPACE IN PASSWORD


            if(space==1)
                {
                    newHtml=html.replace("%text%","Can not have space in password");
                    document.querySelector("#result").textContent=newHtml;
                    switchLightOn(4);
                }
            else
                {


                    //WEAK PASSWORD


                    if(check==1)
                        {
                            newHtml=html.replace("%text%","Weak");
                            document.querySelector("#result").textContent=newHtml;
                            switchLightOn(1);
                        }


                    //MODERATE PASSWORD


                    else if(check==2)
                        {
                            newHtml=html.replace("%text%","Moderate");
                            document.querySelector("#result").textContent=newHtml;
                            switchLightOn(2);
                        }


                    //STRONG PASSWORD


                    else if(check==3)
                        {
                            newHtml=html.replace("%text%","Strong");
                            document.querySelector("#result").textContent=newHtml;
                            switchLightOn(3);
                        }
                }
        }
        

        //SHORT PASSWORD


        else
            {
                console.log("Short");
                newHtml=html.replace("%text%","Not enough characters, Minimum 9 characters required");
                document.querySelector("#result").textContent=newHtml;
                switchLightOn(5);
            }
        
    }
function pageChanger1()
    {
        document.querySelector("#changeBtn-1").classList.add("show");
        document.querySelector("#page-1").classList.add("showPage");
        document.querySelector("#result").classList.remove("showPage");
        for(var x=1;x<5;x++)
            {
                if(x!=1)
                    {
                        document.querySelector("#changeBtn-"+x).classList.remove("show");
                        document.querySelector("#page-"+x).classList.remove("showPage");
                    }
            }
    }
function pageChanger2()
    {
        document.querySelector("#inpFeild").value="";
        document.querySelector("#result").textContent="";
        document.querySelector("#changeBtn-2").classList.add("show");
        document.querySelector("#page-2").classList.add("showPage");
        document.querySelector("#result").classList.add("showPage");
        for(var x=1;x<5;x++)
            {
                if(x!=2)
                    {
                        document.querySelector("#changeBtn-"+x).classList.remove("show");
                        document.querySelector("#page-"+x).classList.remove("showPage");
                    }
            }
    }
function pageChanger3()
    {
        document.querySelector("#changeBtn-3").classList.add("show");
        document.querySelector("#page-3").classList.add("showPage");
        document.querySelector("#result").classList.remove("showPage");
        for(var x=1;x<5;x++)
            {
                if(x!=3)
                    {
                        document.querySelector("#changeBtn-"+x).classList.remove("show");
                        document.querySelector("#page-"+x).classList.remove("showPage");
                    }
            }
    }
function pageChanger4()
    {
        document.querySelector("#changeBtn-4").classList.add("show");
        document.querySelector("#page-4").classList.add("showPage");
        document.querySelector("#result").classList.remove("showPage");
        for(var x=1;x<5;x++)
            {
                if(x!=4)
                    {
                        document.querySelector("#changeBtn-"+x).classList.remove("show");
                        document.querySelector("#page-"+x).classList.remove("showPage");
                    }
            }
    }
document.querySelector("#checkBtn").addEventListener("click",showPass);
document.addEventListener("keyup",function(event){if(event.keyCode==13){showPass()}});
document.querySelector("#changeBtn-1").addEventListener("click",pageChanger1);
document.querySelector("#changeBtn-2").addEventListener("click",pageChanger2);
document.querySelector("#homePlay").addEventListener("click",pageChanger2);
document.querySelector("#changeBtn-3").addEventListener("click",pageChanger3);
document.querySelector("#changeBtn-4").addEventListener("click",pageChanger4);